import React from 'react';
import { Button } from '@/components/ui/button';

interface TemplateCardProps {
  title: string;
  description: string;
  icon: string;
  features: string[];
  onPreview: () => void;
}

const TemplateCard: React.FC<TemplateCardProps> = ({
  title,
  description,
  icon,
  features,
  onPreview
}) => {
  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden">
      <div className="p-6">
        <div className="w-16 h-16 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl flex items-center justify-center mb-4">
          <span className="text-3xl">{icon}</span>
        </div>
        
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          {title}
        </h3>
        
        <p className="text-gray-600 mb-4">
          {description}
        </p>
        
        <ul className="space-y-2 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-sm text-gray-600">
              <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 flex-shrink-0"></span>
              {feature}
            </li>
          ))}
        </ul>
        
        <Button 
          onClick={onPreview}
          className="w-full bg-orange-600 hover:bg-orange-700"
        >
          Preview Template
        </Button>
      </div>
    </div>
  );
};

export default TemplateCard;