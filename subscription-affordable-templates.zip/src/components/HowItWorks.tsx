import React from 'react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      number: "01",
      title: "Choose Your Template",
      description: "Browse our industry-specific templates and select the one that fits your business perfectly.",
      icon: "🎨"
    },
    {
      number: "02", 
      title: "Sign 12-Month Contract",
      description: "No upfront costs! Sign our affordable monthly contract and we'll get started immediately.",
      icon: "📝"
    },
    {
      number: "03",
      title: "We Build & Maintain",
      description: "We build your website/app and provide ongoing maintenance plus 1 free update monthly.",
      icon: "🚀"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get your professional website or app in just 3 simple steps
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center relative">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl">{step.icon}</span>
              </div>
              
              <div className="absolute top-10 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <span className="bg-white text-orange-600 font-bold text-sm px-3 py-1 rounded-full border-2 border-orange-600">
                  {step.number}
                </span>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                {step.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed">
                {step.description}
              </p>

              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-10 left-full w-full">
                  <div className="w-full h-0.5 bg-gradient-to-r from-orange-300 to-transparent"></div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;