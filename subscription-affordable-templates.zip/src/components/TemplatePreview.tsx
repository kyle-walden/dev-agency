import React from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface TemplatePreviewProps {
  isOpen: boolean;
  onClose: () => void;
  template: {
    title: string;
    type: string;
    mockup: JSX.Element;
  } | null;
}

const TemplatePreview: React.FC<TemplatePreviewProps> = ({
  isOpen,
  onClose,
  template
}) => {
  if (!isOpen || !template) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <div>
            <h3 className="text-2xl font-bold text-gray-900">{template.title}</h3>
            <p className="text-gray-600">Template Preview</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        <div className="p-6">
          <div className="bg-gray-100 rounded-lg p-4 min-h-[400px]">
            {template.mockup}
          </div>
          
          <div className="mt-6 flex gap-4">
            <Button className="bg-orange-600 hover:bg-orange-700">
              Choose This Template
            </Button>
            <Button variant="outline" onClick={onClose}>
              Close Preview
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplatePreview;