import React, { useState } from 'react';
import TemplateCard from './TemplateCard';
import TemplatePreview from './TemplatePreview';

const Templates: React.FC = () => {
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  const templates = [
    {
      title: "Restaurant",
      description: "Perfect for cafes, restaurants, and food businesses",
      icon: "🍽️",
      features: ["Online menu display", "Table reservations", "Contact & location", "Photo gallery"],
      type: "restaurant",
      mockup: (
        <div className="space-y-4">
          <div className="bg-orange-600 text-white p-4 rounded">
            <h2 className="text-2xl font-bold">Bella Vista Restaurant</h2>
            <p>Authentic Italian Cuisine</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Menu</div>
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Reservations</div>
          </div>
        </div>
      )
    },
    {
      title: "Guesthouse",
      description: "Ideal for B&Bs, guesthouses, and accommodation",
      icon: "🏨",
      features: ["Room booking system", "Photo galleries", "Guest reviews", "Amenities showcase"],
      type: "guesthouse",
      mockup: (
        <div className="space-y-4">
          <div className="bg-blue-600 text-white p-4 rounded">
            <h2 className="text-2xl font-bold">Sunset Guesthouse</h2>
            <p>Your home away from home</p>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-gray-200 h-24 rounded flex items-center justify-center text-sm">Room 1</div>
            <div className="bg-gray-200 h-24 rounded flex items-center justify-center text-sm">Room 2</div>
            <div className="bg-gray-200 h-24 rounded flex items-center justify-center text-sm">Book Now</div>
          </div>
        </div>
      )
    },
    {
      title: "Gym & Fitness",
      description: "Great for gyms, personal trainers, and fitness centers",
      icon: "💪",
      features: ["Class schedules", "Membership plans", "Trainer profiles", "Equipment showcase"],
      type: "gym",
      mockup: (
        <div className="space-y-4">
          <div className="bg-red-600 text-white p-4 rounded">
            <h2 className="text-2xl font-bold">PowerFit Gym</h2>
            <p>Transform your body, transform your life</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Classes</div>
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Membership</div>
          </div>
        </div>
      )
    },
    {
      title: "Salon & Beauty",
      description: "Perfect for salons, spas, and beauty services",
      icon: "💅",
      features: ["Service booking", "Staff profiles", "Price lists", "Gallery showcase"],
      type: "salon",
      mockup: (
        <div className="space-y-4">
          <div className="bg-pink-600 text-white p-4 rounded">
            <h2 className="text-2xl font-bold">Glamour Salon</h2>
            <p>Beauty & Wellness Services</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Services</div>
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Book Now</div>
          </div>
        </div>
      )
    },
    {
      title: "Contractor",
      description: "Ideal for contractors, builders, and service providers",
      icon: "🔨",
      features: ["Project portfolio", "Service areas", "Quote requests", "Contact forms"],
      type: "contractor",
      mockup: (
        <div className="space-y-4">
          <div className="bg-green-600 text-white p-4 rounded">
            <h2 className="text-2xl font-bold">ProBuild Contractors</h2>
            <p>Quality construction services</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Projects</div>
            <div className="bg-gray-200 h-32 rounded flex items-center justify-center">Get Quote</div>
          </div>
        </div>
      )
    }
  ];

  const handlePreview = (template: any) => {
    setSelectedTemplate(template);
    setPreviewOpen(true);
  };

  return (
    <section id="templates" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Website Templates
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Choose from our professionally designed templates tailored for your industry
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {templates.map((template, index) => (
            <TemplateCard
              key={index}
              title={template.title}
              description={template.description}
              icon={template.icon}
              features={template.features}
              onPreview={() => handlePreview(template)}
            />
          ))}
        </div>
      </div>

      <TemplatePreview
        isOpen={previewOpen}
        onClose={() => setPreviewOpen(false)}
        template={selectedTemplate}
      />
    </section>
  );
};

export default Templates;