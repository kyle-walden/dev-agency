import React from 'react';
import Header from './Header';
import Hero from './Hero';
import HowItWorks from './HowItWorks';
import Templates from './Templates';
import Pricing from './Pricing';
import Contact from './Contact';
import Footer from './Footer';

const AppLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <HowItWorks />
      <Templates />
      <Pricing />
      <Contact />
      <Footer />
    </div>
  );
};

export default AppLayout;
