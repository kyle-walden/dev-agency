import React from 'react';
import { Button } from '@/components/ui/button';

const Hero: React.FC = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="pt-20 pb-16 bg-gradient-to-br from-orange-50 to-red-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Professional Websites & Apps
            <span className="block text-orange-600">No Upfront Cost</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Get a stunning website or app for your business with zero upfront investment. 
            Pay monthly, get ongoing maintenance, and receive 1 free update every month.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button onClick={scrollToContact} size="lg" className="bg-orange-600 hover:bg-orange-700 text-lg px-8 py-4">
              Get Your Website Started
            </Button>
            <Button variant="outline" size="lg" className="border-orange-600 text-orange-600 hover:bg-orange-50 text-lg px-8 py-4">
              View Templates
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🏪</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Restaurants</h3>
              <p className="text-gray-600">Menu displays, online ordering, reservations</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🏨</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Guesthouses</h3>
              <p className="text-gray-600">Booking systems, photo galleries, reviews</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">💪</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Gyms & More</h3>
              <p className="text-gray-600">Salons, contractors, and other businesses</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;