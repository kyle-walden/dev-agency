import React from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

const Pricing: React.FC = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const plans = [
    {
      name: "Basic Website",
      price: "R1,500",
      description: "Perfect for small businesses getting started online",
      features: [
        "5-page responsive website",
        "Mobile-friendly design",
        "Basic SEO optimization",
        "Contact form integration",
        "1 free update per month",
        "Ongoing maintenance & support"
      ],
      popular: false
    },
    {
      name: "Professional Website",
      price: "R2,500",
      description: "Ideal for growing businesses with advanced needs",
      features: [
        "10-page responsive website",
        "Advanced design & animations",
        "E-commerce functionality",
        "Social media integration",
        "Analytics setup",
        "1 free update per month",
        "Priority support"
      ],
      popular: true
    },
    {
      name: "Mobile App",
      price: "R3,500",
      description: "Custom mobile app for iOS and Android",
      features: [
        "Native mobile app",
        "Push notifications",
        "Offline functionality",
        "App store submission",
        "User authentication",
        "1 free update per month",
        "Dedicated support"
      ],
      popular: false
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            No upfront costs. Pay monthly with our 12-month contract. Cancel anytime after the contract period.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div key={index} className={`rounded-xl p-8 ${plan.popular ? 'bg-gradient-to-br from-orange-50 to-red-50 border-2 border-orange-500 relative' : 'bg-gray-50 border border-gray-200'}`}>
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-orange-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {plan.name}
                </h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                  <span className="text-gray-600">/month</span>
                </div>
                <p className="text-gray-600 text-sm">
                  {plan.description}
                </p>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                onClick={scrollToContact}
                className={`w-full ${plan.popular ? 'bg-orange-600 hover:bg-orange-700' : 'bg-gray-800 hover:bg-gray-900'}`}
              >
                Get Started
              </Button>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600">
            All plans include a 12-month contract with no setup fees. 
            <span className="font-semibold text-gray-900"> Cancel anytime after the contract period.</span>
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;