import React from 'react';
import { Button } from '@/components/ui/button';

const Header: React.FC = () => {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-orange-600">WebCraft</h1>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-orange-600 transition-colors">
              Home
            </button>
            <button onClick={() => scrollToSection('how-it-works')} className="text-gray-700 hover:text-orange-600 transition-colors">
              How It Works
            </button>
            <button onClick={() => scrollToSection('templates')} className="text-gray-700 hover:text-orange-600 transition-colors">
              Templates
            </button>
            <button onClick={() => scrollToSection('pricing')} className="text-gray-700 hover:text-orange-600 transition-colors">
              Pricing
            </button>
          </nav>

          <Button onClick={() => scrollToSection('contact')} className="bg-orange-600 hover:bg-orange-700">
            Get Started
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;