import React from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-orange-600 to-red-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-orange-100 max-w-2xl mx-auto">
            Contact us today and let's build your professional website or app with no upfront costs
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <h3 className="text-2xl font-semibold mb-6">Get Your Website Started</h3>
            <p className="text-orange-100 mb-8 text-lg">
              Email us to discuss your project and choose the perfect template for your business. 
              We'll get back to you within 24 hours with a personalized proposal.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center">
                <Mail className="w-6 h-6 text-orange-200 mr-4" />
                <div>
                  <p className="font-semibold">Email Us</p>
                  <a href="mailto:hello@webcraft.co.za" className="text-orange-200 hover:text-white transition-colors">
                    hello@webcraft.co.za
                  </a>
                </div>
              </div>
              
              <div className="flex items-center">
                <Phone className="w-6 h-6 text-orange-200 mr-4" />
                <div>
                  <p className="font-semibold">Call Us</p>
                  <a href="tel:+27123456789" className="text-orange-200 hover:text-white transition-colors">
                    +27 12 345 6789
                  </a>
                </div>
              </div>
              
              <div className="flex items-center">
                <MapPin className="w-6 h-6 text-orange-200 mr-4" />
                <div>
                  <p className="font-semibold">Location</p>
                  <p className="text-orange-200">Cape Town, South Africa</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-8 shadow-xl">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Quick Start Form</h3>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Business Name</label>
                <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent" />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Business Type</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                  <option>Restaurant</option>
                  <option>Guesthouse</option>
                  <option>Gym</option>
                  <option>Salon</option>
                  <option>Contractor</option>
                  <option>Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input type="email" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent" />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                <input type="tel" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent" />
              </div>
              
              <Button className="w-full bg-orange-600 hover:bg-orange-700 py-3">
                Send My Information
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;